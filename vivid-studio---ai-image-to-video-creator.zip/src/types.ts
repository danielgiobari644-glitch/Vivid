export type AspectRatio = "16:9" | "9:16" | "1:1" | "4:5" | "3:2";
export type AnimationType = "none" | "pan-left" | "pan-right" | "zoom-in" | "zoom-out" | "spiral";
export type TransitionType = "none" | "fade" | "slide-left" | "slide-right" | "blur" | "zoom";
export type Resolution = "720p" | "1080p" | "4k";
export type AppTab = "home" | "projects" | "editor" | "templates" | "videos" | "account" | "settings";

export interface Slide {
  id: string;
  imageUrl: string;
  duration: number; // in seconds
  animationType: AnimationType;
  transitionType: TransitionType;
  backgroundColor: string;
  rotation?: number; // 0, 90, 180, 270
  cropRatio?: string; // free, 1:1, 16:9
}

export interface TextTrack {
  id: string;
  text: string;
  startTime: number; // seconds
  duration: number; // seconds
  positionY: number; // 0-100 percentage
  positionX?: number; // 0-100 percentage
  fontSize: number; // px
  fontFamily?: string;
  color: string;
  strokeColor?: string;
  shadowColor?: string;
  animation?: "none" | "fade" | "pop" | "slide";
}

export interface AudioTrack {
  audioUrl?: string;
  title?: string;
  volume: number; // 0-1
  fadeIn: number; // seconds
  fadeOut: number; // seconds
  voiceScript?: string;
}

export interface Project {
  id: string;
  userId?: string;
  title: string;
  description?: string;
  aspectRatio: AspectRatio;
  fps: number;
  backgroundColor: string;
  slides: Slide[];
  textTracks: TextTrack[];
  audioTrack: AudioTrack;
  duration: number;
  createdAt: string;
  updatedAt: string;
}

export interface Template {
  id: string;
  title: string;
  category: string;
  description: string;
  thumbnailUrl: string;
  aspectRatio: AspectRatio;
  slides: Slide[];
  textTracks: TextTrack[];
  audioTrack?: AudioTrack;
  isSystem?: boolean;
}

export interface SavedVideo {
  id: string;
  userId?: string;
  projectId: string;
  title: string;
  videoUrl: string;
  thumbnailUrl: string;
  duration: number;
  resolution: Resolution;
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}
