import React, { useState, useEffect, useRef } from "react";
import { 
  AppTab, 
  Project, 
  Template, 
  SavedVideo, 
  UserProfile, 
  AspectRatio, 
  TransitionType 
} from "./types";
import { 
  auth, 
  onAuthStateChanged, 
  logoutUser, 
  getProjectsFromStorage, 
  saveProjectToStorage, 
  deleteProjectFromStorage, 
  getSavedVideosFromStorage 
} from "./lib/firebase";
import { sampleTemplates, defaultProject } from "./data/sampleData";

import { Header } from "./components/Header";
import { ToastContainer, ToastMessage } from "./components/Toast";
import { AuthModal } from "./components/AuthModal";
import { ExportModal } from "./components/ExportModal";
import { AISceneModal } from "./components/AISceneModal";

import { HomeView } from "./components/views/HomeView";
import { ProjectsView } from "./components/views/ProjectsView";
import { EditorView } from "./components/views/EditorView";
import { TemplatesView } from "./components/views/TemplatesView";
import { RecentVideosView } from "./components/views/RecentVideosView";
import { AccountView } from "./components/views/AccountView";
import { SettingsView } from "./components/views/SettingsView";

export function App() {
  const [activeTab, setActiveTab] = useState<AppTab>("home");
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [user, setUser] = useState<UserProfile | null>(null);

  // Projects & Videos State
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProject, setCurrentProject] = useState<Project>(defaultProject);
  const [savedVideos, setSavedVideos] = useState<SavedVideo[]>([]);
  const [templates] = useState<Template[]>(sampleTemplates);

  // Modals
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showAIWizard, setShowAIWizard] = useState(false);

  // Toast System
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Default Studio Preferences
  const [defaultRatio, setDefaultRatio] = useState<AspectRatio>("16:9");
  const [defaultDuration, setDefaultDuration] = useState<number>(4);
  const [defaultTransition, setDefaultTransition] = useState<TransitionType>("fade");

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const addToast = (message: string, type: "success" | "error" | "info" = "info") => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, message, type }]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Synchronize Dark Mode Class on HTML document root
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  // Firebase Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        setUser({
          uid: fbUser.uid,
          email: fbUser.email,
          displayName: fbUser.displayName,
          photoURL: fbUser.photoURL,
        });
        addToast(`Welcome back, ${fbUser.displayName || fbUser.email}!`, "success");
      } else {
        setUser(null);
      }
      loadUserData();
    });
    return () => unsubscribe();
  }, []);

  // Load Projects and Videos from Storage
  const loadUserData = async () => {
    try {
      const fetchedProjects = await getProjectsFromStorage();
      if (fetchedProjects.length > 0) {
        setProjects(fetchedProjects);
        setCurrentProject(fetchedProjects[0]);
      } else {
        setProjects([defaultProject]);
        setCurrentProject(defaultProject);
        await saveProjectToStorage(defaultProject);
      }

      const fetchedVideos = await getSavedVideosFromStorage();
      setSavedVideos(fetchedVideos);
    } catch (err) {
      console.warn("Error loading user data:", err);
    }
  };

  // Create New Project
  const handleCreateNewProject = (aspectRatio?: AspectRatio) => {
    const newProj: Project = {
      id: `project-${Date.now()}`,
      title: "Untitled Video Project",
      aspectRatio: aspectRatio || defaultRatio,
      fps: 30,
      backgroundColor: "#0a0a0c",
      slides: [
        {
          id: `slide-init-1`,
          imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80",
          duration: defaultDuration,
          animationType: "zoom-in",
          transitionType: defaultTransition,
          backgroundColor: "#0a0a0c",
        },
      ],
      textTracks: [
        {
          id: `text-init-1`,
          text: "MY NEW VIDEO",
          startTime: 0.5,
          duration: 3,
          positionY: 50,
          fontSize: 38,
          color: "#ffffff",
          strokeColor: "#000000",
          animation: "pop",
        },
      ],
      audioTrack: {
        volume: 0.8,
        fadeIn: 0.5,
        fadeOut: 0.5,
      },
      duration: defaultDuration,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setProjects((prev) => [newProj, ...prev]);
    setCurrentProject(newProj);
    saveProjectToStorage(newProj);
    setActiveTab("editor");
    addToast("New video project created!", "success");
  };

  // Open Template
  const handleSelectTemplate = (template: Template) => {
    const newProj: Project = {
      id: `project-template-${Date.now()}`,
      title: `${template.title}`,
      description: template.description,
      aspectRatio: template.aspectRatio,
      fps: 30,
      backgroundColor: "#0a0a0c",
      slides: template.slides.map((s, idx) => ({ ...s, id: `slide-t-${idx}` })),
      textTracks: template.textTracks.map((t, idx) => ({ ...t, id: `text-t-${idx}` })),
      audioTrack: template.audioTrack || { volume: 0.8, fadeIn: 0.5, fadeOut: 0.5 },
      duration: template.slides.reduce((acc, s) => acc + s.duration, 0),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setProjects((prev) => [newProj, ...prev]);
    setCurrentProject(newProj);
    saveProjectToStorage(newProj);
    setActiveTab("editor");
    addToast(`Loaded template: ${template.title}`, "success");
  };

  // Update Project
  const handleUpdateProject = (updated: Project) => {
    setCurrentProject(updated);
    setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    saveProjectToStorage(updated);
  };

  // Duplicate Project
  const handleDuplicateProject = (project: Project) => {
    const dup: Project = {
      ...project,
      id: `project-dup-${Date.now()}`,
      title: `${project.title} (Copy)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setProjects((prev) => [dup, ...prev]);
    saveProjectToStorage(dup);
    addToast("Project duplicated!", "success");
  };

  // Delete Project
  const handleDeleteProject = async (projectId: string) => {
    await deleteProjectFromStorage(projectId);
    setProjects((prev) => prev.filter((p) => p.id !== projectId));
    addToast("Project deleted", "info");
  };

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 font-sans transition-colors duration-200 flex flex-col">
      {/* Top Glassmorphism Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        user={user}
        onOpenAuth={() => setShowAuthModal(true)}
        onLogout={async () => {
          await logoutUser();
          addToast("Logged out successfully", "info");
        }}
        onNewProject={() => handleCreateNewProject()}
        onExportClick={() => setShowExportModal(true)}
      />

      {/* Main Content Body */}
      <main className="flex-1">
        {activeTab === "home" && (
          <HomeView
            onNewProject={handleCreateNewProject}
            onOpenAIWizard={() => setShowAIWizard(true)}
            onOpenTemplate={handleSelectTemplate}
            onOpenProject={(p) => {
              setCurrentProject(p);
              setActiveTab("editor");
            }}
            projects={projects}
            templates={templates}
          />
        )}

        {activeTab === "projects" && (
          <ProjectsView
            projects={projects}
            onOpenProject={(p) => {
              setCurrentProject(p);
              setActiveTab("editor");
            }}
            onDuplicateProject={handleDuplicateProject}
            onDeleteProject={handleDeleteProject}
            onNewProject={() => handleCreateNewProject()}
          />
        )}

        {activeTab === "editor" && (
          <EditorView
            project={currentProject}
            onUpdateProject={handleUpdateProject}
            onExportClick={() => setShowExportModal(true)}
            onToast={addToast}
          />
        )}

        {activeTab === "templates" && (
          <TemplatesView
            templates={templates}
            onSelectTemplate={handleSelectTemplate}
          />
        )}

        {activeTab === "videos" && <RecentVideosView videos={savedVideos} />}

        {activeTab === "account" && (
          <AccountView
            user={user}
            projects={projects}
            videos={savedVideos}
            onOpenAuth={() => setShowAuthModal(true)}
            onLogout={async () => {
              await logoutUser();
              addToast("Logged out successfully", "info");
            }}
            onToast={addToast}
          />
        )}

        {activeTab === "settings" && (
          <SettingsView
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            defaultRatio={defaultRatio}
            setDefaultRatio={setDefaultRatio}
            defaultDuration={defaultDuration}
            setDefaultDuration={setDefaultDuration}
            defaultTransition={defaultTransition}
            setDefaultTransition={setDefaultTransition}
            onToast={addToast}
          />
        )}
      </main>

      {/* Hidden canvas for export capture if needed */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />

      {/* Modals */}
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onSuccess={(u) => {
            setUser(u);
            addToast(`Signed in as ${u.email}`, "success");
          }}
        />
      )}

      {showExportModal && (
        <ExportModal
          project={currentProject}
          canvasRef={canvasRef}
          onClose={() => setShowExportModal(false)}
          onSuccess={(vid) => {
            setSavedVideos((prev) => [vid, ...prev]);
            addToast("Video successfully rendered and saved!", "success");
          }}
        />
      )}

      {showAIWizard && (
        <AISceneModal
          aspectRatio={currentProject.aspectRatio}
          onApplyScript={(newProj) => {
            handleUpdateProject({ ...currentProject, ...newProj });
            setActiveTab("editor");
            addToast("AI Storyboard generated and loaded into Editor!", "success");
          }}
          onClose={() => setShowAIWizard(false)}
        />
      )}
    </div>
  );
}

export default App;
