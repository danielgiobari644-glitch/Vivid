import React from "react";
import { AspectRatio, TransitionType } from "../../types";
import { Settings, Sliders, Monitor, Palette, Sparkles } from "lucide-react";

interface SettingsViewProps {
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  defaultRatio: AspectRatio;
  setDefaultRatio: (ratio: AspectRatio) => void;
  defaultDuration: number;
  setDefaultDuration: (sec: number) => void;
  defaultTransition: TransitionType;
  setDefaultTransition: (trans: TransitionType) => void;
  onToast: (msg: string, type?: "success" | "error" | "info") => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  darkMode,
  setDarkMode,
  defaultRatio,
  setDefaultRatio,
  defaultDuration,
  setDefaultDuration,
  defaultTransition,
  setDefaultTransition,
  onToast,
}) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 flex flex-col gap-8">
      <div>
        <h1 className="font-extrabold text-2xl text-zinc-900 dark:text-white flex items-center gap-2.5">
          <Settings className="w-6 h-6 text-amber-500" />
          Studio Preferences
        </h1>
        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
          Configure default settings for new video projects.
        </p>
      </div>

      <div className="flex flex-col gap-5">
        {/* Appearance Settings */}
        <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-zinc-900 dark:text-white">Dark Theme Mode</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">Toggle dark studio background canvas</p>
            </div>
          </div>

          <button
            onClick={() => {
              setDarkMode(!darkMode);
              onToast(`Switched to ${!darkMode ? "Dark" : "Light"} theme`, "info");
            }}
            className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
              darkMode ? "bg-amber-500" : "bg-zinc-300"
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                darkMode ? "translate-x-6" : "translate-x-0"
              }`}
            />
          </button>
        </div>

        {/* Default Canvas Aspect Ratio */}
        <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex flex-col gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
              <Monitor className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-zinc-900 dark:text-white">Default Canvas Aspect Ratio</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">Default aspect ratio when creating new projects</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-2">
            {(["16:9", "9:16", "1:1", "4:5", "3:2"] as AspectRatio[]).map((ratio) => (
              <button
                key={ratio}
                onClick={() => {
                  setDefaultRatio(ratio);
                  onToast(`Default ratio set to ${ratio}`, "success");
                }}
                className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                  defaultRatio === ratio
                    ? "bg-amber-500 text-white border-amber-500 shadow-md shadow-amber-500/20"
                    : "bg-zinc-50 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700"
                }`}
              >
                {ratio}
              </button>
            ))}
          </div>
        </div>

        {/* Slide Duration Defaults */}
        <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-zinc-900 dark:text-white">Default Slide Duration</h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">Seconds allocated per new image slide</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {[2, 4, 5, 8].map((sec) => (
              <button
                key={sec}
                onClick={() => {
                  setDefaultDuration(sec);
                  onToast(`Default slide duration set to ${sec}s`, "success");
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border ${
                  defaultDuration === sec
                    ? "bg-amber-500 text-white border-amber-500"
                    : "bg-zinc-50 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700"
                }`}
              >
                {sec}s
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
