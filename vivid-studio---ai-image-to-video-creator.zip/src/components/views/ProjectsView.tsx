import React, { useState } from "react";
import { Project } from "../../types";
import { 
  FileVideo, 
  Plus, 
  Search, 
  Trash2, 
  Copy, 
  Edit3, 
  Clock, 
  Layers 
} from "lucide-react";

interface ProjectsViewProps {
  projects: Project[];
  onOpenProject: (project: Project) => void;
  onDuplicateProject: (project: Project) => void;
  onDeleteProject: (projectId: string) => void;
  onNewProject: () => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  onOpenProject,
  onDuplicateProject,
  onDeleteProject,
  onNewProject,
}) => {
  const [search, setSearch] = useState("");
  const [filterRatio, setFilterRatio] = useState<string>("all");

  const filtered = projects.filter((p) => {
    const matchesSearch = p.title.toLowerCase().includes(search.toLowerCase());
    const matchesRatio = filterRatio === "all" || p.aspectRatio === filterRatio;
    return matchesSearch && matchesRatio;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-8">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-extrabold text-2xl text-zinc-900 dark:text-white flex items-center gap-2.5">
            <FileVideo className="w-6 h-6 text-amber-500" />
            My Video Projects
          </h1>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
            Manage your saved video projects, duplicate, or continue editing.
          </p>
        </div>

        <button
          onClick={onNewProject}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-white font-bold text-xs shadow-md shadow-amber-500/20 hover:opacity-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Project</span>
        </button>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search projects by title..."
            className="w-full rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 pl-10 pr-4 py-2 text-xs text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <select
          value={filterRatio}
          onChange={(e) => setFilterRatio(e.target.value)}
          className="w-full sm:w-48 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 px-3 py-2 text-xs text-zinc-900 dark:text-white"
        >
          <option value="all">All Aspect Ratios</option>
          <option value="16:9">16:9 Landscape</option>
          <option value="9:16">9:16 Vertical</option>
          <option value="1:1">1:1 Square</option>
          <option value="4:5">4:5 Portrait</option>
          <option value="3:2">3:2 Classic</option>
        </select>
      </div>

      {/* Projects Grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((project) => {
            const firstImg = project.slides[0]?.imageUrl;
            return (
              <div
                key={project.id}
                className="group rounded-2xl overflow-hidden bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm hover:shadow-xl transition-all flex flex-col"
              >
                {/* Thumbnail Header */}
                <div
                  onClick={() => onOpenProject(project)}
                  className="relative aspect-video bg-zinc-950 overflow-hidden cursor-pointer"
                >
                  {firstImg ? (
                    <img
                      src={firstImg}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-zinc-600">
                      <Layers className="w-8 h-8" />
                    </div>
                  )}

                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-[10px] font-bold text-white">
                    {project.aspectRatio}
                  </div>

                  <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[10px] font-bold text-white flex items-center gap-1">
                    <Clock className="w-3 h-3 text-amber-400" />
                    {project.duration}s
                  </div>
                </div>

                {/* Content */}
                <div className="p-4 flex flex-col justify-between flex-1 gap-4">
                  <div>
                    <h3
                      onClick={() => onOpenProject(project)}
                      className="font-extrabold text-sm text-zinc-900 dark:text-white cursor-pointer hover:text-amber-500 transition-colors line-clamp-1"
                    >
                      {project.title}
                    </h3>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
                      {project.slides.length} slides • {project.textTracks.length} text overlays
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-3 border-t border-zinc-100 dark:border-zinc-800/80">
                    <button
                      onClick={() => onOpenProject(project)}
                      className="flex items-center gap-1 text-xs font-bold text-amber-500 hover:text-amber-600"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onDuplicateProject(project)}
                        className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-600 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                        title="Duplicate Project"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteProject(project.id)}
                        className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors"
                        title="Delete Project"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center py-16 p-8 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 flex flex-col items-center justify-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
            <FileVideo className="w-6 h-6" />
          </div>
          <h3 className="font-extrabold text-base text-zinc-900 dark:text-white">
            No projects found
          </h3>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-sm">
            Create your first video project or select a template to start editing right away.
          </p>
          <button
            onClick={onNewProject}
            className="mt-2 px-5 py-2.5 rounded-xl bg-amber-500 text-white font-bold text-xs shadow-md shadow-amber-500/20"
          >
            Create New Video
          </button>
        </div>
      )}
    </div>
  );
};
