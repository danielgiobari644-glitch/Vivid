import React, { useState } from "react";
import { Template } from "../../types";
import { LayoutTemplate, Search, ArrowRight, Play, Sparkles } from "lucide-react";

interface TemplatesViewProps {
  templates: Template[];
  onSelectTemplate: (template: Template) => void;
}

export const TemplatesView: React.FC<TemplatesViewProps> = ({ templates, onSelectTemplate }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [search, setSearch] = useState("");

  const categories = [
    "all",
    "YouTube Shorts",
    "TikTok",
    "Instagram Reel",
    "Church Announcement",
    "Bible Verse Video",
  ];

  const filtered = templates.filter((t) => {
    const matchesCategory = selectedCategory === "all" || t.category === selectedCategory;
    const matchesSearch = t.title.toLowerCase().includes(search.toLowerCase()) || t.description.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-8">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="font-extrabold text-2xl text-zinc-900 dark:text-white flex items-center gap-2.5">
          <LayoutTemplate className="w-6 h-6 text-amber-500" />
          Video Template Library
        </h1>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          Start with pre-designed video layouts for social media, promos, announcements, and quotes.
        </p>
      </div>

      {/* Filter Tabs & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex overflow-x-auto w-full sm:w-auto p-1 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 gap-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? "bg-amber-500 text-white shadow-sm"
                  : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
              }`}
            >
              {cat === "all" ? "All Templates" : cat}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search templates..."
            className="w-full rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 pl-10 pr-4 py-2 text-xs text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((template) => (
          <div
            key={template.id}
            onClick={() => onSelectTemplate(template)}
            className="group cursor-pointer rounded-2xl overflow-hidden bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm hover:shadow-xl transition-all flex flex-col justify-between"
          >
            <div className="relative aspect-video bg-zinc-950 overflow-hidden">
              <img
                src={template.thumbnailUrl}
                alt={template.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-[10px] font-bold text-white uppercase border border-white/20">
                {template.category}
              </div>
              <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-amber-500 text-white font-bold text-[10px]">
                {template.aspectRatio}
              </div>
            </div>

            <div className="p-4 flex flex-col gap-2">
              <h3 className="font-extrabold text-sm text-zinc-900 dark:text-white group-hover:text-amber-500 transition-colors">
                {template.title}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2">
                {template.description}
              </p>

              <div className="pt-3 flex items-center justify-between border-t border-zinc-100 dark:border-zinc-800/80 text-xs font-bold text-amber-500">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> Use Template
                </span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
