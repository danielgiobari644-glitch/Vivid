import React, { useState, useEffect, useRef } from "react";
import { 
  Project, 
  Slide, 
  TextTrack, 
  AspectRatio, 
  AnimationType, 
  TransitionType 
} from "../../types";
import { 
  getCanvasDimensions, 
  renderCanvasFrame, 
  preloadProjectImages 
} from "../../lib/videoEngine";
import { CropRotateModal } from "../CropRotateModal";
import { AISceneModal } from "../AISceneModal";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Plus, 
  Trash2, 
  Copy, 
  Crop, 
  MoveUp, 
  MoveDown, 
  Type as TypeIcon, 
  Music, 
  Sparkles, 
  Wand2, 
  Settings2, 
  Image as ImageIcon, 
  Download, 
  Sliders,
  Volume2,
  VolumeX,
  Mic,
  Undo2,
  Redo2,
  Layers
} from "lucide-react";

interface EditorViewProps {
  project: Project;
  onUpdateProject: (updated: Project) => void;
  onExportClick: () => void;
  onToast: (msg: string, type?: "success" | "error" | "info") => void;
}

export const EditorView: React.FC<EditorViewProps> = ({
  project,
  onUpdateProject,
  onExportClick,
  onToast,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [selectedSlideIndex, setSelectedSlideIndex] = useState(0);
  const [selectedTextTrackId, setSelectedTextTrackId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"slides" | "text" | "audio" | "canvas">("slides");
  
  // Modals
  const [cropSlide, setCropSlide] = useState<Slide | null>(null);
  const [showAIWizard, setShowAIWizard] = useState(false);
  
  // Undo / Redo History
  const [history, setHistory] = useState<Project[]>([project]);
  const [historyIndex, setHistoryIndex] = useState(0);

  // AI Generation States
  const [aiImagePrompt, setAiImagePrompt] = useState("");
  const [generatingImage, setGeneratingImage] = useState(false);
  const [ttsScript, setTtsScript] = useState(project.audioTrack?.voiceScript || "");
  const [generatingTTS, setGeneratingTTS] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(performance.now());

  // Calculate total project duration
  const totalDuration = project.slides.reduce((acc, s) => acc + (s.duration || 4), 0);

  // Preload images whenever project slides change
  useEffect(() => {
    preloadProjectImages(project);
  }, [project.slides]);

  // Canvas dimensions
  const dims = getCanvasDimensions(project.aspectRatio);

  // Save changes to project state with Undo history
  const pushProjectUpdate = (newProject: Project) => {
    const updated = {
      ...newProject,
      duration: newProject.slides.reduce((acc, s) => acc + (s.duration || 4), 0),
      updatedAt: new Date().toISOString(),
    };
    onUpdateProject(updated);

    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(updated);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const prev = history[historyIndex - 1];
      setHistoryIndex(historyIndex - 1);
      onUpdateProject(prev);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const next = history[historyIndex + 1];
      setHistoryIndex(historyIndex + 1);
      onUpdateProject(next);
    }
  };

  // Playback Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const render = () => {
      renderCanvasFrame(ctx, dims.width, dims.height, project, currentTime);
    };

    render();

    if (isPlaying) {
      const animate = (now: number) => {
        const delta = (now - lastTimeRef.current) / 1000;
        lastTimeRef.current = now;

        setCurrentTime((prev) => {
          const next = prev + delta;
          if (next >= totalDuration) {
            setIsPlaying(false);
            return 0;
          }
          return next;
        });

        animationFrameRef.current = requestAnimationFrame(animate);
      };

      lastTimeRef.current = performance.now();
      animationFrameRef.current = requestAnimationFrame(animate);
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, currentTime, project, dims]);

  // Image File Upload Handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newSlides: Slide[] = [];
    Array.from(files).forEach((file: File, idx) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const url = event.target?.result as string;
        const slide: Slide = {
          id: `slide-${Date.now()}-${idx}`,
          imageUrl: url,
          duration: 4,
          animationType: "zoom-in",
          transitionType: "fade",
          backgroundColor: project.backgroundColor || "#000000",
        };
        newSlides.push(slide);

        if (newSlides.length === files.length) {
          pushProjectUpdate({
            ...project,
            slides: [...project.slides, ...newSlides],
          });
          onToast(`Added ${newSlides.length} new slide(s)`, "success");
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // AI Image Generator
  const handleGenerateAIImage = async () => {
    if (!aiImagePrompt.trim()) return;
    setGeneratingImage(true);
    try {
      const res = await fetch("/api/ai/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: aiImagePrompt, aspectRatio: project.aspectRatio }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Failed to generate AI image");
      }

      const newSlide: Slide = {
        id: `slide-ai-${Date.now()}`,
        imageUrl: data.imageUrl,
        duration: 4,
        animationType: "zoom-in",
        transitionType: "fade",
        backgroundColor: "#000000",
      };

      pushProjectUpdate({
        ...project,
        slides: [...project.slides, newSlide],
      });

      setAiImagePrompt("");
      onToast("AI slide background generated!", "success");
    } catch (err: any) {
      onToast(err.message || "AI image generation error", "error");
    } finally {
      setGeneratingImage(false);
    }
  };

  // AI Voiceover Generator (TTS)
  const handleGenerateTTS = async () => {
    if (!ttsScript.trim()) return;
    setGeneratingTTS(true);
    try {
      const res = await fetch("/api/ai/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: ttsScript }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Failed to generate voiceover");
      }

      pushProjectUpdate({
        ...project,
        audioTrack: {
          ...project.audioTrack,
          voiceScript: ttsScript,
          audioUrl: `data:audio/mp3;base64,${data.audioBase64}`,
          title: "AI Voiceover Narration",
        },
      });

      onToast("Voiceover narration generated with Gemini TTS!", "success");
    } catch (err: any) {
      onToast(err.message || "Voiceover generation error", "error");
    } finally {
      setGeneratingTTS(false);
    }
  };

  // Slide Reordering & Operations
  const moveSlide = (index: number, direction: "up" | "down") => {
    const targetIdx = direction === "up" ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= project.slides.length) return;
    const slides = [...project.slides];
    const temp = slides[index];
    slides[index] = slides[targetIdx];
    slides[targetIdx] = temp;
    pushProjectUpdate({ ...project, slides });
  };

  const deleteSlide = (index: number) => {
    const slides = project.slides.filter((_, i) => i !== index);
    pushProjectUpdate({ ...project, slides });
    if (selectedSlideIndex >= slides.length) {
      setSelectedSlideIndex(Math.max(0, slides.length - 1));
    }
  };

  const duplicateSlide = (index: number) => {
    const slideToDup = project.slides[index];
    const dup: Slide = {
      ...slideToDup,
      id: `slide-dup-${Date.now()}`,
    };
    const slides = [...project.slides];
    slides.splice(index + 1, 0, dup);
    pushProjectUpdate({ ...project, slides });
  };

  // Text Overlay Operations
  const addTextTrack = () => {
    const newTrack: TextTrack = {
      id: `text-${Date.now()}`,
      text: "NEW TITLE OVERLAY",
      startTime: Math.min(currentTime, totalDuration),
      duration: 3,
      positionY: 50,
      fontSize: 36,
      color: "#ffffff",
      strokeColor: "#000000",
      shadowColor: "#000000",
      animation: "pop",
    };
    pushProjectUpdate({
      ...project,
      textTracks: [...project.textTracks, newTrack],
    });
    setSelectedTextTrackId(newTrack.id);
  };

  const updateSelectedSlide = (updates: Partial<Slide>) => {
    const slides = [...project.slides];
    if (slides[selectedSlideIndex]) {
      slides[selectedSlideIndex] = { ...slides[selectedSlideIndex], ...updates };
      pushProjectUpdate({ ...project, slides });
    }
  };

  const updateTextTrack = (id: string, updates: Partial<TextTrack>) => {
    const textTracks = project.textTracks.map((t) => (t.id === id ? { ...t, ...updates } : t));
    pushProjectUpdate({ ...project, textTracks });
  };

  const deleteTextTrack = (id: string) => {
    const textTracks = project.textTracks.filter((t) => t.id !== id);
    pushProjectUpdate({ ...project, textTracks });
    if (selectedTextTrackId === id) setSelectedTextTrackId(null);
  };

  const currentSlide = project.slides[selectedSlideIndex];
  const selectedTextTrack = project.textTracks.find((t) => t.id === selectedTextTrackId);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col gap-6">
      {/* Top Studio Control Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm">
        <div className="flex items-center gap-3">
          <input
            type="text"
            value={project.title}
            onChange={(e) => pushProjectUpdate({ ...project, title: e.target.value })}
            className="font-extrabold text-lg bg-transparent text-zinc-900 dark:text-white focus:outline-none border-b border-transparent focus:border-amber-500"
          />
          <span className="text-xs font-bold uppercase px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-500 border border-amber-500/20">
            {project.aspectRatio}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Undo / Redo */}
          <button
            onClick={handleUndo}
            disabled={historyIndex <= 0}
            className="p-2 rounded-xl text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-40"
            title="Undo"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            onClick={handleRedo}
            disabled={historyIndex >= history.length - 1}
            className="p-2 rounded-xl text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-40"
            title="Redo"
          >
            <Redo2 className="w-4 h-4" />
          </button>

          {/* AI Storyboard Wizard */}
          <button
            onClick={() => setShowAIWizard(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-white font-bold text-xs shadow-md shadow-amber-500/20 hover:opacity-95"
          >
            <Wand2 className="w-4 h-4" />
            <span>AI Storyboard</span>
          </button>

          {/* Export MP4 */}
          <button
            onClick={onExportClick}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 font-bold text-xs shadow-sm hover:opacity-90"
          >
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Main Studio Editor Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Media & Slides Manager (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-100 dark:border-zinc-800">
              <h3 className="font-extrabold text-sm text-zinc-900 dark:text-white flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-amber-500" />
                Slides & Media ({project.slides.length})
              </h3>

              <label className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-500 text-white font-bold text-xs cursor-pointer hover:bg-amber-600 transition-colors">
                <Plus className="w-3.5 h-3.5" />
                <span>Upload</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* AI Image Generation Prompt Box */}
            <div className="p-3 rounded-xl bg-gradient-to-r from-amber-500/5 via-rose-500/5 to-indigo-500/5 border border-amber-500/20 flex flex-col gap-2">
              <span className="text-[11px] font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> Generate Slide Background with AI
              </span>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={aiImagePrompt}
                  onChange={(e) => setAiImagePrompt(e.target.value)}
                  placeholder="Describe an image prompt..."
                  className="flex-1 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 px-3 py-1.5 text-xs text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:outline-none"
                />
                <button
                  onClick={handleGenerateAIImage}
                  disabled={generatingImage || !aiImagePrompt.trim()}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 text-white text-xs font-bold disabled:opacity-50"
                >
                  {generatingImage ? "..." : "Gen"}
                </button>
              </div>
            </div>

            {/* Slide Items List */}
            <div className="flex flex-col gap-2.5 max-h-[380px] overflow-y-auto pr-1">
              {project.slides.map((slide, idx) => {
                const isSelected = idx === selectedSlideIndex;
                return (
                  <div
                    key={slide.id}
                    onClick={() => setSelectedSlideIndex(idx)}
                    className={`group p-2.5 rounded-xl border transition-all flex items-center gap-3 cursor-pointer ${
                      isSelected
                        ? "bg-amber-500/10 border-amber-500 shadow-sm"
                        : "bg-zinc-50 dark:bg-zinc-800/60 border-zinc-200/80 dark:border-zinc-700/80 hover:border-zinc-400"
                    }`}
                  >
                    <span className="text-xs font-bold text-zinc-400 w-4">{idx + 1}</span>

                    <div className="relative w-14 h-10 rounded-lg bg-black overflow-hidden border border-zinc-700 shrink-0">
                      <img src={slide.imageUrl} alt="" className="w-full h-full object-cover" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-zinc-800 dark:text-zinc-200 truncate">
                        Slide {idx + 1} ({slide.duration}s)
                      </div>
                      <div className="text-[10px] text-zinc-400 capitalize truncate">
                        {slide.animationType} • {slide.transitionType}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          moveSlide(idx, "up");
                        }}
                        disabled={idx === 0}
                        className="p-1 rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-white disabled:opacity-30"
                      >
                        <MoveUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          moveSlide(idx, "down");
                        }}
                        disabled={idx === project.slides.length - 1}
                        className="p-1 rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-white disabled:opacity-30"
                      >
                        <MoveDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setCropSlide(slide);
                        }}
                        className="p-1 rounded text-zinc-400 hover:text-amber-500"
                        title="Crop / Rotate"
                      >
                        <Crop className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          duplicateSlide(idx);
                        }}
                        className="p-1 rounded text-zinc-400 hover:text-indigo-500"
                        title="Duplicate"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteSlide(idx);
                        }}
                        className="p-1 rounded text-zinc-400 hover:text-rose-500"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Center Canvas Preview Player (5 cols) */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center gap-4">
          <div className="relative w-full p-4 rounded-3xl bg-zinc-950 border border-zinc-800 shadow-2xl flex flex-col items-center justify-center">
            {/* HTML5 Canvas Element */}
            <canvas
              ref={canvasRef}
              width={dims.width}
              height={dims.height}
              className="max-w-full max-h-[420px] object-contain rounded-xl shadow-lg border border-zinc-800"
            />

            {/* Scrubber & Player Controls */}
            <div className="w-full mt-4 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min={0}
                  max={totalDuration || 1}
                  step={0.1}
                  value={currentTime}
                  onChange={(e) => {
                    setCurrentTime(Number(e.target.value));
                    setIsPlaying(false);
                  }}
                  className="w-full h-2 rounded-lg bg-zinc-800 accent-amber-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between text-xs font-bold text-zinc-400">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="p-2.5 rounded-xl bg-amber-500 text-white hover:bg-amber-600 transition-colors"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => {
                      setCurrentTime(0);
                      setIsPlaying(false);
                    }}
                    className="p-2.5 rounded-xl bg-zinc-800 text-zinc-300 hover:bg-zinc-700"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>

                <div>
                  <span className="text-white">{currentTime.toFixed(1)}s</span> / {totalDuration.toFixed(1)}s
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Inspector Panel (3 cols) */}
        <div className="lg:col-span-3 flex flex-col gap-4">
          <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex flex-col gap-4">
            {/* Inspector Navigation Tabs */}
            <div className="flex rounded-xl bg-zinc-100 dark:bg-zinc-800 p-1">
              {[
                { id: "slides", label: "Slide", icon: <Sliders className="w-3.5 h-3.5" /> },
                { id: "text", label: "Text", icon: <TypeIcon className="w-3.5 h-3.5" /> },
                { id: "audio", label: "Audio", icon: <Music className="w-3.5 h-3.5" /> },
                { id: "canvas", label: "Canvas", icon: <Settings2 className="w-3.5 h-3.5" /> },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                    activeTab === tab.id
                      ? "bg-amber-500 text-white shadow-sm"
                      : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
                  }`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </div>

            {/* TAB: Slide Inspector */}
            {activeTab === "slides" && currentSlide && (
              <div className="flex flex-col gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                    Slide Duration (Seconds)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={30}
                    value={currentSlide.duration}
                    onChange={(e) => updateSelectedSlide({ duration: Number(e.target.value) })}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-2 text-xs text-zinc-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                    Ken Burns Pan & Zoom Animation
                  </label>
                  <select
                    value={currentSlide.animationType}
                    onChange={(e) => updateSelectedSlide({ animationType: e.target.value as AnimationType })}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-2 text-xs text-zinc-900 dark:text-white"
                  >
                    <option value="none">Static (No Motion)</option>
                    <option value="zoom-in">Zoom In</option>
                    <option value="zoom-out">Zoom Out</option>
                    <option value="pan-left">Pan Left</option>
                    <option value="pan-right">Pan Right</option>
                    <option value="spiral">Spiral Zoom</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                    Transition Effect to Next Slide
                  </label>
                  <select
                    value={currentSlide.transitionType}
                    onChange={(e) => updateSelectedSlide({ transitionType: e.target.value as TransitionType })}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-2 text-xs text-zinc-900 dark:text-white"
                  >
                    <option value="none">Cut (No Transition)</option>
                    <option value="fade">Cross Fade</option>
                    <option value="slide-left">Slide Left</option>
                    <option value="blur">Blur Transition</option>
                    <option value="zoom">Zoom Transition</option>
                  </select>
                </div>
              </div>
            )}

            {/* TAB: Text Inspector */}
            {activeTab === "text" && (
              <div className="flex flex-col gap-4">
                <button
                  onClick={addTextTrack}
                  className="w-full py-2.5 rounded-xl bg-amber-500 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Text Overlay</span>
                </button>

                {/* Text Tracks List */}
                <div className="flex flex-col gap-2 max-h-48 overflow-y-auto">
                  {project.textTracks.map((t) => (
                    <div
                      key={t.id}
                      onClick={() => setSelectedTextTrackId(t.id)}
                      className={`p-2 rounded-xl border text-xs font-bold flex items-center justify-between cursor-pointer ${
                        selectedTextTrackId === t.id
                          ? "bg-amber-500/10 border-amber-500 text-amber-500"
                          : "bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700"
                      }`}
                    >
                      <span className="truncate max-w-[140px]">{t.text}</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteTextTrack(t.id);
                        }}
                        className="text-zinc-400 hover:text-rose-500"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {selectedTextTrack && (
                  <div className="flex flex-col gap-3 pt-3 border-t border-zinc-200 dark:border-zinc-800">
                    <div>
                      <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                        Overlay Text
                      </label>
                      <input
                        type="text"
                        value={selectedTextTrack.text}
                        onChange={(e) => updateTextTrack(selectedTextTrack.id, { text: e.target.value })}
                        className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-2 text-xs text-zinc-900 dark:text-white"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                          Font Size
                        </label>
                        <input
                          type="number"
                          value={selectedTextTrack.fontSize}
                          onChange={(e) => updateTextTrack(selectedTextTrack.id, { fontSize: Number(e.target.value) })}
                          className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-2 text-xs text-zinc-900 dark:text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                          Position Y (%)
                        </label>
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={selectedTextTrack.positionY}
                          onChange={(e) => updateTextTrack(selectedTextTrack.id, { positionY: Number(e.target.value) })}
                          className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-2 text-xs text-zinc-900 dark:text-white"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB: Audio Inspector & AI Voiceover */}
            {activeTab === "audio" && (
              <div className="flex flex-col gap-4">
                <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 flex flex-col gap-2">
                  <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5">
                    <Mic className="w-4 h-4 text-amber-500" /> AI Voiceover Narration
                  </span>
                  <textarea
                    value={ttsScript}
                    onChange={(e) => setTtsScript(e.target.value)}
                    placeholder="Enter script for voice narration..."
                    rows={3}
                    className="w-full rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 p-2 text-xs text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:outline-none resize-none"
                  />
                  <button
                    onClick={handleGenerateTTS}
                    disabled={generatingTTS || !ttsScript.trim()}
                    className="w-full py-2 rounded-xl bg-amber-500 text-white font-bold text-xs disabled:opacity-50 flex items-center justify-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{generatingTTS ? "Generating Narration..." : "Generate AI Voiceover"}</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB: Canvas Settings */}
            {activeTab === "canvas" && (
              <div className="flex flex-col gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                    Aspect Ratio Format
                  </label>
                  <select
                    value={project.aspectRatio}
                    onChange={(e) => pushProjectUpdate({ ...project, aspectRatio: e.target.value as AspectRatio })}
                    className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-2 text-xs text-zinc-900 dark:text-white"
                  >
                    <option value="16:9">16:9 Widescreen (YouTube)</option>
                    <option value="9:16">9:16 Vertical (Shorts/TikTok)</option>
                    <option value="1:1">1:1 Square (Feed)</option>
                    <option value="4:5">4:5 Portrait</option>
                    <option value="3:2">3:2 Classic</option>
                  </select>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Panel: Multi-Track Studio Timeline */}
      <div className="p-4 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex flex-col gap-3">
        <div className="flex items-center justify-between pb-2 border-b border-zinc-100 dark:border-zinc-800">
          <span className="font-extrabold text-xs text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-amber-500" /> Multi-Track Timeline
          </span>
          <span className="text-xs font-bold text-zinc-400">Total: {totalDuration.toFixed(1)}s</span>
        </div>

        {/* Timeline Tracks Visualizer */}
        <div className="flex flex-col gap-2 relative bg-zinc-950 p-3 rounded-2xl border border-zinc-800 overflow-x-auto">
          {/* Slides Track */}
          <div className="flex items-center gap-1 h-10 w-full">
            {project.slides.map((slide, idx) => {
              const widthPct = (slide.duration / totalDuration) * 100;
              const isSelected = idx === selectedSlideIndex;
              return (
                <div
                  key={slide.id}
                  onClick={() => setSelectedSlideIndex(idx)}
                  style={{ width: `${widthPct}%` }}
                  className={`h-full rounded-lg border flex items-center px-2 gap-2 cursor-pointer transition-all ${
                    isSelected
                      ? "bg-amber-500/30 border-amber-400 text-white font-bold"
                      : "bg-zinc-800/80 border-zinc-700 text-zinc-300"
                  }`}
                >
                  <img src={slide.imageUrl} alt="" className="w-6 h-6 rounded object-cover" />
                  <span className="text-[10px] truncate">Slide {idx + 1} ({slide.duration}s)</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Modals */}
      {cropSlide && (
        <CropRotateModal
          slide={cropSlide}
          onSave={(updated) => updateSelectedSlide(updated)}
          onClose={() => setCropSlide(null)}
        />
      )}

      {showAIWizard && (
        <AISceneModal
          aspectRatio={project.aspectRatio}
          onApplyScript={(newProj) => {
            pushProjectUpdate({ ...project, ...newProj });
            onToast("AI Storyboard script applied to video project!", "success");
          }}
          onClose={() => setShowAIWizard(false)}
        />
      )}
    </div>
  );
};
