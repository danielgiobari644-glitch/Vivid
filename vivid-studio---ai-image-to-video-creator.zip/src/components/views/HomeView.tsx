import React from "react";
import { AspectRatio, Project, Template } from "../../types";
import { 
  Sparkles, 
  Plus, 
  Wand2, 
  ArrowRight, 
  LayoutTemplate, 
  Clock, 
  Video, 
  Layers, 
  Zap, 
  Flame, 
  CheckCircle 
} from "lucide-react";

interface HomeViewProps {
  onNewProject: (aspectRatio?: AspectRatio) => void;
  onOpenAIWizard: () => void;
  onOpenTemplate: (template: Template) => void;
  onOpenProject: (project: Project) => void;
  projects: Project[];
  templates: Template[];
}

export const HomeView: React.FC<HomeViewProps> = ({
  onNewProject,
  onOpenAIWizard,
  onOpenTemplate,
  onOpenProject,
  projects,
  templates,
}) => {
  const aspectRatios: { ratio: AspectRatio; label: string; desc: string }[] = [
    { ratio: "16:9", label: "Landscape (16:9)", desc: "YouTube & Presentations" },
    { ratio: "9:16", label: "Vertical (9:16)", desc: "Shorts, TikTok, Instagram Reels" },
    { ratio: "1:1", label: "Square (1:1)", desc: "Feeds & Quotes" },
    { ratio: "4:5", label: "Portrait (4:5)", desc: "Social Media Posts" },
    { ratio: "3:2", label: "Classic (3:2)", desc: "Photography Slideshows" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-10">
      {/* Hero Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-950 text-white p-8 sm:p-12 border border-zinc-800 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-amber-500/20 via-rose-500/20 to-indigo-500/0 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl flex flex-col gap-5">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold w-fit">
            <Sparkles className="w-4 h-4" />
            <span>NEXT-GEN AI IMAGE TO VIDEO STUDIO</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
            Transform Images into <span className="bg-gradient-to-r from-amber-400 via-rose-400 to-indigo-400 bg-clip-text text-transparent">Cinematic Videos</span>
          </h1>

          <p className="text-sm sm:text-base text-zinc-300 font-medium leading-relaxed">
            Multi-track timeline editor with Ken Burns zoom animations, custom transitions, AI voice narration, and high-res video rendering.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onNewProject("16:9")}
              className="flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 font-extrabold text-xs text-white shadow-xl shadow-amber-500/25 hover:scale-[1.02] transition-transform"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Project</span>
            </button>

            <button
              onClick={onOpenAIWizard}
              className="flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-white/10 hover:bg-white/15 backdrop-blur-md border border-white/20 font-bold text-xs text-white transition-all"
            >
              <Wand2 className="w-4 h-4 text-amber-400" />
              <span>Generate with AI Wizard</span>
            </button>
          </div>
        </div>
      </div>

      {/* Aspect Ratio Quick Selection */}
      <div className="flex flex-col gap-4">
        <h2 className="font-extrabold text-xl text-zinc-900 dark:text-white flex items-center gap-2">
          <Video className="w-5 h-5 text-amber-500" />
          Choose Your Video Canvas Format
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {aspectRatios.map((item) => (
            <button
              key={item.ratio}
              onClick={() => onNewProject(item.ratio)}
              className="group p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 hover:border-amber-500 dark:hover:border-amber-500 shadow-sm hover:shadow-md transition-all text-left flex flex-col justify-between"
            >
              <div>
                <span className="font-extrabold text-sm text-zinc-900 dark:text-white group-hover:text-amber-500 transition-colors">
                  {item.label}
                </span>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
                  {item.desc}
                </p>
              </div>
              <div className="mt-4 flex items-center justify-between text-xs font-bold text-amber-500 opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Start Project</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Featured Templates */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h2 className="font-extrabold text-xl text-zinc-900 dark:text-white flex items-center gap-2">
            <LayoutTemplate className="w-5 h-5 text-amber-500" />
            Popular Video Templates
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {templates.slice(0, 3).map((template) => (
            <div
              key={template.id}
              onClick={() => onOpenTemplate(template)}
              className="group cursor-pointer rounded-2xl overflow-hidden bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm hover:shadow-xl transition-all"
            >
              <div className="relative aspect-video bg-zinc-950 overflow-hidden">
                <img
                  src={template.thumbnailUrl}
                  alt={template.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-[10px] font-bold text-white uppercase border border-white/20">
                  {template.category}
                </div>
              </div>
              <div className="p-4 flex flex-col gap-2">
                <h3 className="font-extrabold text-sm text-zinc-900 dark:text-white group-hover:text-amber-500 transition-colors">
                  {template.title}
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2">
                  {template.description}
                </p>
                <div className="pt-2 flex items-center justify-between border-t border-zinc-100 dark:border-zinc-800/80 text-xs font-semibold text-amber-500">
                  <span>Use Template</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Projects */}
      {projects.length > 0 && (
        <div className="flex flex-col gap-4">
          <h2 className="font-extrabold text-xl text-zinc-900 dark:text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-500" />
            Recent Studio Projects
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {projects.slice(0, 4).map((project) => (
              <div
                key={project.id}
                onClick={() => onOpenProject(project)}
                className="group cursor-pointer rounded-2xl p-4 bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300">
                      {project.aspectRatio}
                    </span>
                    <span className="text-[10px] text-zinc-400">
                      {project.slides.length} slides
                    </span>
                  </div>
                  <h4 className="font-extrabold text-sm text-zinc-900 dark:text-white group-hover:text-amber-500 transition-colors line-clamp-1">
                    {project.title}
                  </h4>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
                    Duration: {project.duration}s
                  </p>
                </div>
                <div className="mt-4 pt-2 border-t border-zinc-100 dark:border-zinc-800 text-xs font-bold text-amber-500 flex items-center justify-between">
                  <span>Open in Editor</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
