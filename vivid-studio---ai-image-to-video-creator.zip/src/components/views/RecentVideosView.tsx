import React, { useState } from "react";
import { SavedVideo } from "../../types";
import { Film, Download, Play, Clock, X } from "lucide-react";

interface RecentVideosViewProps {
  videos: SavedVideo[];
}

export const RecentVideosView: React.FC<RecentVideosViewProps> = ({ videos }) => {
  const [playingVideo, setPlayingVideo] = useState<SavedVideo | null>(null);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-8">
      <div>
        <h1 className="font-extrabold text-2xl text-zinc-900 dark:text-white flex items-center gap-2.5">
          <Film className="w-6 h-6 text-amber-500" />
          Exported Video Gallery
        </h1>
        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
          View, play back, and download your rendered MP4 videos.
        </p>
      </div>

      {videos.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos.map((vid) => (
            <div
              key={vid.id}
              className="group rounded-2xl overflow-hidden bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm hover:shadow-xl transition-all flex flex-col"
            >
              <div className="relative aspect-video bg-zinc-950 overflow-hidden">
                {vid.thumbnailUrl ? (
                  <img src={vid.thumbnailUrl} alt={vid.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-zinc-600">
                    <Film className="w-8 h-8" />
                  </div>
                )}
                <button
                  onClick={() => setPlayingVideo(vid)}
                  className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-amber-500/90 text-white flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
                >
                  <Play className="w-5 h-5 ml-0.5" />
                </button>

                <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-[10px] font-bold text-white uppercase">
                  {vid.resolution}
                </div>
              </div>

              <div className="p-4 flex flex-col justify-between flex-1 gap-3">
                <div>
                  <h3 className="font-extrabold text-sm text-zinc-900 dark:text-white line-clamp-1">
                    {vid.title}
                  </h3>
                  <div className="text-xs text-zinc-400 mt-1 flex items-center gap-2">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {vid.duration}s
                    </span>
                    <span>•</span>
                    <span>{new Date(vid.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <a
                  href={vid.videoUrl}
                  download={`${vid.title.replace(/\s+/g, "_")}.mp4`}
                  className="py-2 px-3 rounded-xl bg-amber-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm hover:bg-amber-600 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download MP4</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 p-8 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 flex flex-col items-center justify-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
            <Film className="w-6 h-6" />
          </div>
          <h3 className="font-extrabold text-base text-zinc-900 dark:text-white">
            No exported videos yet
          </h3>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-sm">
            Render your first video in the Studio Editor to see it in your video gallery.
          </p>
        </div>
      )}

      {/* Video Modal Player */}
      {playingVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-2xl rounded-3xl bg-zinc-900 border border-zinc-800 shadow-2xl p-6 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
              <h3 className="font-extrabold text-base text-white">{playingVideo.title}</h3>
              <button onClick={() => setPlayingVideo(null)} className="p-1 rounded-full text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="relative aspect-video bg-black rounded-2xl overflow-hidden border border-zinc-800">
              <video src={playingVideo.videoUrl} controls autoPlay className="w-full h-full object-contain" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
