import React, { useState } from "react";
import { UserProfile, Project, SavedVideo } from "../../types";
import { 
  User, 
  Mail, 
  ShieldCheck, 
  FileVideo, 
  Film, 
  Clock, 
  LogOut, 
  LogIn, 
  Sparkles,
  KeyRound
} from "lucide-react";
import { resetPassword } from "../../lib/firebase";

interface AccountViewProps {
  user: UserProfile | null;
  projects: Project[];
  videos: SavedVideo[];
  onOpenAuth: () => void;
  onLogout: () => void;
  onToast: (msg: string, type?: "success" | "error" | "info") => void;
}

export const AccountView: React.FC<AccountViewProps> = ({
  user,
  projects,
  videos,
  onOpenAuth,
  onLogout,
  onToast,
}) => {
  const [resetEmailSent, setResetEmailSent] = useState(false);

  const handleReset = async () => {
    if (!user?.email) return;
    try {
      await resetPassword(user.email);
      setResetEmailSent(true);
      onToast("Password reset email sent!", "success");
    } catch (err: any) {
      onToast(err.message || "Failed to send reset email", "error");
    }
  };

  const totalRenderedSeconds = videos.reduce((acc, v) => acc + (v.duration || 0), 0);
  const totalRenderedMinutes = (totalRenderedSeconds / 60).toFixed(1);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 flex flex-col gap-8">
      {/* Profile Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 p-0.5 shadow-lg shadow-amber-500/20">
            <div className="w-full h-full bg-zinc-900 rounded-[14px] flex items-center justify-center text-white text-xl font-extrabold overflow-hidden">
              {user?.photoURL ? (
                <img src={user.photoURL} alt="" className="w-full h-full object-cover" />
              ) : (
                (user?.displayName || user?.email || "U").charAt(0).toUpperCase()
              )}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-extrabold text-lg text-zinc-900 dark:text-white">
                {user?.displayName || (user ? "Creator Account" : "Guest Mode")}
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 text-[10px] font-bold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                {user ? "Firebase Cloud Sync Active" : "Local Storage Mode"}
              </span>
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 flex items-center gap-1">
              <Mail className="w-3.5 h-3.5" />
              {user?.email || "Signed in locally (Connect Firebase to sync across devices)"}
            </p>
          </div>
        </div>

        {user ? (
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-rose-500/20 bg-rose-500/10 text-rose-500 font-bold text-xs hover:bg-rose-500 hover:text-white transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        ) : (
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-amber-500 text-white font-bold text-xs shadow-md shadow-amber-500/20 hover:bg-amber-600"
          >
            <LogIn className="w-4 h-4" />
            <span>Sign In / Register</span>
          </button>
        )}
      </div>

      {/* Creator Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
            <FileVideo className="w-6 h-6" />
          </div>
          <div>
            <span className="text-2xl font-extrabold text-zinc-900 dark:text-white">
              {projects.length}
            </span>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">Total Projects</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
            <Film className="w-6 h-6" />
          </div>
          <div>
            <span className="text-2xl font-extrabold text-zinc-900 dark:text-white">
              {videos.length}
            </span>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">Exported MP4 Videos</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <span className="text-2xl font-extrabold text-zinc-900 dark:text-white">
              {totalRenderedMinutes} min
            </span>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">Rendered Video Time</p>
          </div>
        </div>
      </div>

      {/* Security Actions */}
      {user && (
        <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex items-center justify-between">
          <div>
            <h4 className="font-extrabold text-sm text-zinc-900 dark:text-white flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-amber-500" /> Password & Security
            </h4>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Send a password reset email via Firebase Auth.
            </p>
          </div>

          <button
            onClick={handleReset}
            disabled={resetEmailSent}
            className="px-4 py-2 rounded-xl border border-zinc-200 dark:border-zinc-700 text-xs font-bold text-zinc-800 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 disabled:opacity-50"
          >
            {resetEmailSent ? "Email Sent" : "Reset Password"}
          </button>
        </div>
      )}
    </div>
  );
};
