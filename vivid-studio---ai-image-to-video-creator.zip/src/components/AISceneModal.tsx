import React, { useState } from "react";
import { AspectRatio, Project, Slide, TextTrack } from "../types";
import { Sparkles, Wand2, X, Loader2 } from "lucide-react";

interface AISceneModalProps {
  aspectRatio: AspectRatio;
  onApplyScript: (newProject: Partial<Project>) => void;
  onClose: () => void;
}

export const AISceneModal: React.FC<AISceneModalProps> = ({ aspectRatio, onApplyScript, onClose }) => {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("cinematic");
  const [numScenes, setNumScenes] = useState(4);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const samplePrompts = [
    "5 Morning Habits of Successful Entrepreneurs",
    "Church Youth Worship Night Announcement",
    "Futuristic AI Technology Product Reveal",
    "Top 3 Hidden Travel Gems in Italy",
    "Inspiring Quote: Strength in Adversity",
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/ai/generate-script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, style, numScenes, aspectRatio }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || "Failed to generate AI script");
      }

      const script = data.script;

      // Convert generated scenes into Slides & TextTracks
      const slides: Slide[] = [];
      const textTracks: TextTrack[] = [];

      let currentTime = 0;

      // Unsplash stock image search keywords fallback pool
      const stockImages = [
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80",
        "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80",
        "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80",
        "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80",
        "https://images.unsplash.com/photo-1438232992991-995b7058bbb3?auto=format&fit=crop&w=1200&q=80",
      ];

      script.scenes.forEach((scene: any, idx: number) => {
        const slideId = `slide-ai-${idx + 1}`;
        const duration = scene.duration || 4;

        slides.push({
          id: slideId,
          imageUrl: stockImages[idx % stockImages.length],
          duration,
          animationType: scene.animationType || "zoom-in",
          transitionType: scene.transitionType || "fade",
          backgroundColor: "#0d0e15",
        });

        // Add title text track
        if (scene.title) {
          textTracks.push({
            id: `text-title-${idx + 1}`,
            text: scene.title.toUpperCase(),
            startTime: currentTime + 0.3,
            duration: duration - 0.6,
            positionY: 35,
            fontSize: 36,
            color: "#ffffff",
            strokeColor: "#000000",
            animation: "pop",
          });
        }

        // Add caption text track
        if (scene.caption) {
          textTracks.push({
            id: `text-caption-${idx + 1}`,
            text: scene.caption,
            startTime: currentTime + 0.8,
            duration: duration - 1.0,
            positionY: 70,
            fontSize: 24,
            color: "#fbbf24",
            strokeColor: "#000000",
            animation: "fade",
          });
        }

        currentTime += duration;
      });

      onApplyScript({
        title: script.title || prompt,
        description: `AI Generated Video: ${prompt}`,
        aspectRatio,
        slides,
        textTracks,
        duration: currentTime,
        audioTrack: {
          title: script.musicStyle || "AI Cinematic Theme",
          volume: 0.8,
          fadeIn: 0.5,
          fadeOut: 0.5,
          voiceScript: script.scenes.map((s: any) => s.voiceScript).join(" "),
        },
      });

      onClose();
    } catch (err: any) {
      setError(err.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in-50">
      <div className="w-full max-w-xl rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl p-6 flex flex-col gap-5 overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shadow-md shadow-amber-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-zinc-900 dark:text-white">
                AI Video Storyboard Generator
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Generate complete video scenes, script, and captions powered by Gemini AI
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-zinc-400 hover:text-zinc-600 dark:hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Input Form */}
        <div className="flex flex-col gap-4">
          <div>
            <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1.5">
              What is your video about?
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. 5 Motivational Secrets for Daily Productivity..."
              rows={3}
              className="w-full rounded-2xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 p-3.5 text-xs text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-amber-500 resize-none"
            />
          </div>

          {/* Quick Prompts */}
          <div>
            <span className="text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 block mb-1.5">
              Quick Suggestions:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {samplePrompts.map((sp, idx) => (
                <button
                  key={idx}
                  onClick={() => setPrompt(sp)}
                  className="px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-amber-500/10 hover:text-amber-500 dark:hover:bg-amber-500/20 text-[11px] text-zinc-600 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 transition-colors"
                >
                  {sp}
                </button>
              ))}
            </div>
          </div>

          {/* Options */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                Visual Style
              </label>
              <select
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-2.5 text-xs text-zinc-900 dark:text-white"
              >
                <option value="cinematic">Cinematic & Dramatic</option>
                <option value="vibrant">Vibrant & High Energy</option>
                <option value="minimal">Minimal & Aesthetic</option>
                <option value="inspirational">Inspirational & Peaceful</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
                Number of Scenes
              </label>
              <select
                value={numScenes}
                onChange={(e) => setNumScenes(Number(e.target.value))}
                className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 p-2.5 text-xs text-zinc-900 dark:text-white"
              >
                <option value={3}>3 Scenes (~12s)</option>
                <option value={4}>4 Scenes (~16s)</option>
                <option value={5}>5 Scenes (~20s)</option>
                <option value={6}>6 Scenes (~24s)</option>
              </select>
            </div>
          </div>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-500 font-semibold">
            {error}
          </div>
        )}

        {/* Action Button */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-200 dark:border-zinc-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            Cancel
          </button>
          <button
            onClick={handleGenerate}
            disabled={loading || !prompt.trim()}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 text-white text-xs font-bold shadow-lg shadow-amber-500/20 hover:opacity-95 disabled:opacity-50 transition-opacity"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Crafting Scenes with Gemini...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4" />
                <span>Generate Video Storyboard</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
