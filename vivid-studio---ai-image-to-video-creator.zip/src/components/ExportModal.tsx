import React, { useState, useEffect } from "react";
import { Project, Resolution, SavedVideo } from "../types";
import { exportVideoClientSide } from "../lib/videoEngine";
import { saveExportedVideo } from "../lib/firebase";
import confetti from "canvas-confetti";
import { Download, Film, CheckCircle2, Loader2, X, Sparkles, MonitorPlay } from "lucide-react";

interface ExportModalProps {
  project: Project;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  onClose: () => void;
  onSuccess: (video: SavedVideo) => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ project, canvasRef, onClose, onSuccess }) => {
  const [resolution, setResolution] = useState<Resolution>("1080p");
  const [exporting, setExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [videoBlobUrl, setVideoBlobUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startExport = async () => {
    if (!canvasRef.current) {
      setError("Canvas element not available for export");
      return;
    }

    setExporting(true);
    setProgress(0);
    setError(null);

    try {
      // Execute client-side export
      const blob = await exportVideoClientSide(canvasRef.current, project, (pct) => {
        setProgress(pct);
      });

      const url = URL.createObjectURL(blob);
      setVideoBlobUrl(url);

      // Trigger Confetti Celebration
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });

      // Save metadata
      const savedVid: SavedVideo = {
        id: `video-${Date.now()}`,
        projectId: project.id,
        title: project.title || "Exported Video",
        videoUrl: url,
        thumbnailUrl: project.slides[0]?.imageUrl || "",
        duration: project.duration,
        resolution,
        createdAt: new Date().toISOString(),
      };

      await saveExportedVideo(savedVid);
      onSuccess(savedVid);
    } catch (err: any) {
      setError(err.message || "Failed to render video");
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in-50">
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl p-6 flex flex-col gap-5 overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center gap-2">
            <Film className="w-5 h-5 text-amber-500" />
            <h3 className="font-extrabold text-base text-zinc-900 dark:text-white">
              Export Video (MP4)
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-zinc-400 hover:text-zinc-600 dark:hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {!videoBlobUrl ? (
          <div className="flex flex-col gap-4">
            {/* Resolution Selection */}
            <div>
              <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-2">
                Export Resolution
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(["720p", "1080p", "4k"] as Resolution[]).map((res) => (
                  <button
                    key={res}
                    onClick={() => setResolution(res)}
                    disabled={exporting}
                    className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                      resolution === res
                        ? "bg-amber-500 text-white border-amber-500 shadow-md shadow-amber-500/20"
                        : "bg-zinc-50 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:border-amber-400"
                    }`}
                  >
                    {res.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            {/* Render Details */}
            <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/80 dark:border-zinc-700/80 flex flex-col gap-2 text-xs">
              <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                <span>Aspect Ratio:</span>
                <span className="font-bold text-zinc-900 dark:text-white">{project.aspectRatio}</span>
              </div>
              <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                <span>Total Duration:</span>
                <span className="font-bold text-zinc-900 dark:text-white">{project.duration}s</span>
              </div>
              <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                <span>Framerate:</span>
                <span className="font-bold text-zinc-900 dark:text-white">{project.fps || 30} FPS</span>
              </div>
            </div>

            {/* Progress Bar */}
            {exporting && (
              <div className="flex flex-col gap-2">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-amber-500 flex items-center gap-1.5">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" /> Rendering frames...
                  </span>
                  <span className="text-zinc-700 dark:text-zinc-300">{progress}%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 transition-all duration-200"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            )}

            {error && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-500 font-semibold">
                {error}
              </div>
            )}

            {/* Render Action */}
            <button
              onClick={startExport}
              disabled={exporting}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 text-white font-extrabold text-xs shadow-lg shadow-amber-500/20 hover:opacity-95 disabled:opacity-50 transition-opacity flex items-center justify-center gap-2"
            >
              {exporting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing Video Stream...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Start Video Render ({resolution})</span>
                </>
              )}
            </button>
          </div>
        ) : (
          /* Render Finished Screen */
          <div className="flex flex-col gap-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <div>
              <h4 className="font-extrabold text-lg text-zinc-900 dark:text-white">
                Video Render Complete! 🎉
              </h4>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
                Your high quality {resolution} MP4 video is ready to download.
              </p>
            </div>

            <div className="relative rounded-2xl overflow-hidden bg-black aspect-video border border-zinc-800">
              <video src={videoBlobUrl} controls className="w-full h-full object-contain" />
            </div>

            <div className="flex items-center gap-2">
              <a
                href={videoBlobUrl}
                download={`${project.title.replace(/\s+/g, "_")}_${resolution}.mp4`}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-white font-extrabold text-xs shadow-md shadow-amber-500/20 hover:opacity-95 flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Download MP4</span>
              </a>
              <button
                onClick={onClose}
                className="px-4 py-3 rounded-xl border border-zinc-200 dark:border-zinc-700 text-xs font-bold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
