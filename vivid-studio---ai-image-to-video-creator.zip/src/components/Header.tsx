import React from "react";
import { AppTab, UserProfile } from "../types";
import { 
  Clapperboard, 
  Sparkles, 
  FileVideo, 
  LayoutTemplate, 
  Film, 
  User, 
  Settings, 
  Sun, 
  Moon, 
  Plus, 
  Download,
  LogOut,
  LogIn
} from "lucide-react";

interface HeaderProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  user: UserProfile | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onNewProject: () => void;
  onExportClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  darkMode,
  setDarkMode,
  user,
  onOpenAuth,
  onLogout,
  onNewProject,
  onExportClick,
}) => {
  const navItems: { tab: AppTab; label: string; icon: React.ReactNode }[] = [
    { tab: "home", label: "Home", icon: <Sparkles className="w-4 h-4" /> },
    { tab: "projects", label: "My Projects", icon: <FileVideo className="w-4 h-4" /> },
    { tab: "editor", label: "Studio Editor", icon: <Clapperboard className="w-4 h-4" /> },
    { tab: "templates", label: "Templates", icon: <LayoutTemplate className="w-4 h-4" /> },
    { tab: "videos", label: "Recent Videos", icon: <Film className="w-4 h-4" /> },
    { tab: "account", label: "Account", icon: <User className="w-4 h-4" /> },
    { tab: "settings", label: "Settings", icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-white/70 dark:bg-zinc-950/70 border-b border-zinc-200/80 dark:border-zinc-800/80 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo */}
        <div 
          onClick={() => setActiveTab("home")}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 p-0.5 shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-zinc-900 rounded-[10px] flex items-center justify-center text-white">
              <Clapperboard className="w-5 h-5 text-amber-400" />
            </div>
          </div>
          <div>
            <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-zinc-900 via-zinc-800 to-amber-600 dark:from-white dark:via-zinc-200 dark:to-amber-400 bg-clip-text text-transparent">
              Vivid Studio
            </span>
            <span className="hidden sm:inline-block ml-2 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
              AI VIDEO PRO
            </span>
          </div>
        </div>

        {/* Center Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1 bg-zinc-100/70 dark:bg-zinc-900/70 p-1 rounded-xl border border-zinc-200/50 dark:border-zinc-800/50">
          {navItems.map((item) => {
            const isActive = activeTab === item.tab;
            return (
              <button
                key={item.tab}
                onClick={() => setActiveTab(item.tab)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? "bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm border border-zinc-200/60 dark:border-zinc-700/60"
                    : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-200/50 dark:hover:bg-zinc-800/50"
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-2.5">
          {/* Theme Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-xl text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
            title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Quick Actions */}
          {activeTab === "editor" && (
            <button
              onClick={onExportClick}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-white font-semibold text-xs shadow-md shadow-amber-500/20 hover:opacity-95 transition-opacity"
            >
              <Download className="w-4 h-4" />
              <span>Export MP4</span>
            </button>
          )}

          <button
            onClick={onNewProject}
            className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 font-semibold text-xs shadow-sm hover:opacity-90 transition-opacity"
          >
            <Plus className="w-4 h-4" />
            <span>New Video</span>
          </button>

          {/* User Profile / Auth */}
          {user ? (
            <div className="flex items-center gap-2 pl-2 border-l border-zinc-200 dark:border-zinc-800">
              <div 
                onClick={() => setActiveTab("account")}
                className="w-8 h-8 rounded-full bg-amber-500 text-white font-bold flex items-center justify-center text-xs cursor-pointer overflow-hidden border border-amber-400/50"
              >
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || "User"} className="w-full h-full object-cover" />
                ) : (
                  (user.displayName || user.email || "U").charAt(0).toUpperCase()
                )}
              </div>
              <button
                onClick={onLogout}
                className="p-2 rounded-xl text-zinc-500 hover:text-rose-500 dark:text-zinc-400 dark:hover:text-rose-400 transition-colors"
                title="Log Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-zinc-300 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 font-semibold text-xs hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
            >
              <LogIn className="w-4 h-4 text-amber-500" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Subnav */}
      <div className="md:hidden flex overflow-x-auto px-4 py-2 border-t border-zinc-200/60 dark:border-zinc-800/60 gap-1 scrollbar-none">
        {navItems.map((item) => {
          const isActive = activeTab === item.tab;
          return (
            <button
              key={item.tab}
              onClick={() => setActiveTab(item.tab)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                isActive
                  ? "bg-amber-500 text-white"
                  : "bg-zinc-100 dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400"
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
