import React, { useState } from "react";
import { Slide } from "../types";
import { X, RotateCw, Crop, Check } from "lucide-react";

interface CropRotateModalProps {
  slide: Slide;
  onSave: (updatedSlide: Slide) => void;
  onClose: () => void;
}

export const CropRotateModal: React.FC<CropRotateModalProps> = ({ slide, onSave, onClose }) => {
  const [rotation, setRotation] = useState<number>(slide.rotation || 0);
  const [cropRatio, setCropRatio] = useState<string>(slide.cropRatio || "16:9");

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  const handleSave = () => {
    onSave({
      ...slide,
      rotation,
      cropRatio,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden p-6 flex flex-col gap-5">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-200 dark:border-zinc-800">
          <h3 className="font-extrabold text-base text-zinc-900 dark:text-white flex items-center gap-2">
            <Crop className="w-5 h-5 text-amber-500" />
            Image Crop & Rotation
          </h3>
          <button onClick={onClose} className="p-1 rounded-full text-zinc-400 hover:text-zinc-600 dark:hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Image Preview Window */}
        <div className="relative w-full h-64 rounded-2xl bg-zinc-950 flex items-center justify-center overflow-hidden border border-zinc-800">
          <img
            src={slide.imageUrl}
            alt="Slide preview"
            style={{ transform: `rotate(${rotation}deg)` }}
            className="max-w-full max-h-full object-contain transition-transform duration-300"
          />
        </div>

        {/* Controls */}
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={handleRotate}
            className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-zinc-300 dark:border-zinc-700 font-semibold text-xs text-zinc-800 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <RotateCw className="w-4 h-4 text-amber-500" />
            <span>Rotate 90° ({rotation}°)</span>
          </button>

          <div className="flex items-center gap-1 rounded-xl bg-zinc-100 dark:bg-zinc-800 p-1">
            {["16:9", "9:16", "1:1"].map((ratio) => (
              <button
                key={ratio}
                onClick={() => setCropRatio(ratio)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  cropRatio === ratio
                    ? "bg-amber-500 text-white shadow-sm"
                    : "text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white"
                }`}
              >
                {ratio}
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-200 dark:border-zinc-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-white text-xs font-semibold shadow-md shadow-amber-500/20 hover:opacity-95"
          >
            <Check className="w-4 h-4" />
            <span>Save Adjustments</span>
          </button>
        </div>
      </div>
    </div>
  );
};
