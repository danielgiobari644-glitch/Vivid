import { Project, Slide, TextTrack, AspectRatio } from "../types";

export interface CanvasDimensions {
  width: number;
  height: number;
}

export function getCanvasDimensions(aspectRatio: AspectRatio, maxContainerWidth: number = 800): CanvasDimensions {
  switch (aspectRatio) {
    case "9:16":
      // Vertical / Shorts
      return { width: 450, height: 800 };
    case "1:1":
      // Square
      return { width: 600, height: 600 };
    case "4:5":
      // Portrait / Instagram
      return { width: 560, height: 700 };
    case "3:2":
      // Landscape classic
      return { width: 750, height: 500 };
    case "16:9":
    default:
      // Landscape Widescreen
      return { width: 800, height: 450 };
  }
}

// Image Loader Cache
const imageCache: Map<string, HTMLImageElement> = new Map();

export async function preloadProjectImages(project: Project): Promise<void> {
  const promises = project.slides.map((slide) => {
    if (!slide.imageUrl) return Promise.resolve();
    if (imageCache.has(slide.imageUrl)) return Promise.resolve();
    return new Promise<void>((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        imageCache.set(slide.imageUrl, img);
        resolve();
      };
      img.onerror = () => {
        resolve();
      };
      img.src = slide.imageUrl;
    });
  });
  await Promise.all(promises);
}

// Render a specific timestamp onto the HTML5 Canvas
export function renderCanvasFrame(
  ctx: CanvasRenderingContext2D,
  canvasWidth: number,
  canvasHeight: number,
  project: Project,
  currentTime: number
) {
  // Clear canvas background
  ctx.fillStyle = project.backgroundColor || "#0a0a0c";
  ctx.fillRect(0, 0, canvasWidth, canvasHeight);

  if (!project.slides || project.slides.length === 0) {
    // Empty state on canvas
    ctx.fillStyle = "#64748b";
    ctx.font = "bold 20px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("Upload or select images to start", canvasWidth / 2, canvasHeight / 2);
    return;
  }

  // Calculate slide timings
  let accumulatedTime = 0;
  let currentSlideIndex = 0;
  let currentSlideTime = 0;

  for (let i = 0; i < project.slides.length; i++) {
    const slide = project.slides[i];
    const duration = slide.duration || 4;
    if (currentTime >= accumulatedTime && currentTime < accumulatedTime + duration) {
      currentSlideIndex = i;
      currentSlideTime = currentTime - accumulatedTime;
      break;
    }
    accumulatedTime += duration;
    if (i === project.slides.length - 1) {
      // Clamped to end
      currentSlideIndex = i;
      currentSlideTime = duration;
    }
  }

  const slide = project.slides[currentSlideIndex];
  const slideDuration = slide.duration || 4;
  const progress = Math.min(1, Math.max(0, currentSlideTime / slideDuration));

  // Check for transition with next slide
  const nextSlide = project.slides[currentSlideIndex + 1];
  const transitionDuration = 0.8; // seconds
  const isTransitioning = nextSlide && currentSlideTime >= slideDuration - transitionDuration;

  // Render current slide background/image
  renderSlideWithKenBurns(ctx, canvasWidth, canvasHeight, slide, progress);

  // Render transition overlay if applicable
  if (isTransitioning && nextSlide) {
    const transProgress = (currentSlideTime - (slideDuration - transitionDuration)) / transitionDuration;
    ctx.save();
    ctx.globalAlpha = transProgress;
    renderSlideWithKenBurns(ctx, canvasWidth, canvasHeight, nextSlide, 0);
    ctx.restore();
  }

  // Render Text Overlays
  if (project.textTracks && project.textTracks.length > 0) {
    for (const textTrack of project.textTracks) {
      if (
        currentTime >= textTrack.startTime &&
        currentTime <= textTrack.startTime + textTrack.duration
      ) {
        renderTextOverlay(ctx, canvasWidth, canvasHeight, textTrack, currentTime - textTrack.startTime);
      }
    }
  }
}

// Render Slide with Ken Burns Pan/Zoom
function renderSlideWithKenBurns(
  ctx: CanvasRenderingContext2D,
  canvasW: number,
  canvasH: number,
  slide: Slide,
  progress: number
) {
  const img = imageCache.get(slide.imageUrl);
  if (!img || !img.complete) {
    // Fill placeholder background color
    ctx.fillStyle = slide.backgroundColor || "#1e1e24";
    ctx.fillRect(0, 0, canvasW, canvasH);
    return;
  }

  ctx.save();

  // Apply slide rotation if set
  if (slide.rotation) {
    ctx.translate(canvasW / 2, canvasH / 2);
    ctx.rotate((slide.rotation * Math.PI) / 180);
    ctx.translate(-canvasW / 2, -canvasH / 2);
  }

  // Calculate Ken Burns scale and position
  let scale = 1.0;
  let offsetX = 0;
  let offsetY = 0;

  switch (slide.animationType) {
    case "zoom-in":
      scale = 1.0 + 0.18 * progress;
      break;
    case "zoom-out":
      scale = 1.18 - 0.18 * progress;
      break;
    case "pan-left":
      scale = 1.12;
      offsetX = (1 - progress) * (canvasW * 0.08) - canvasW * 0.04;
      break;
    case "pan-right":
      scale = 1.12;
      offsetX = progress * (canvasW * 0.08) - canvasW * 0.04;
      break;
    case "spiral":
      scale = 1.05 + 0.1 * Math.sin(progress * Math.PI);
      offsetX = Math.cos(progress * Math.PI * 2) * 15;
      offsetY = Math.sin(progress * Math.PI * 2) * 15;
      break;
    case "none":
    default:
      scale = 1.0;
      break;
  }

  // Fit image inside aspect ratio box while preserving ratio
  const imgRatio = img.width / img.height;
  const canvasRatio = canvasW / canvasH;

  let drawW = canvasW;
  let drawH = canvasH;

  if (imgRatio > canvasRatio) {
    drawH = canvasW / imgRatio;
  } else {
    drawW = canvasH * imgRatio;
  }

  // Center image on canvas
  const centerX = canvasW / 2 + offsetX;
  const centerY = canvasH / 2 + offsetY;

  const finalW = drawW * scale;
  const finalH = drawH * scale;

  ctx.drawImage(img, centerX - finalW / 2, centerY - finalH / 2, finalW, finalH);

  ctx.restore();
}

// Render Text Overlay onto Canvas
function renderTextOverlay(
  ctx: CanvasRenderingContext2D,
  canvasW: number,
  canvasH: number,
  textTrack: TextTrack,
  activeTime: number
) {
  ctx.save();

  // Handle entry animation
  let opacity = 1.0;
  let scale = 1.0;
  const animTime = 0.4;

  if (activeTime < animTime) {
    const p = activeTime / animTime;
    if (textTrack.animation === "fade") {
      opacity = p;
    } else if (textTrack.animation === "pop") {
      scale = 0.5 + 0.5 * p;
      opacity = p;
    } else if (textTrack.animation === "slide") {
      opacity = p;
    }
  }

  ctx.globalAlpha = opacity;

  // Positioning
  const xPercent = textTrack.positionX !== undefined ? textTrack.positionX : 50;
  const yPercent = textTrack.positionY !== undefined ? textTrack.positionY : 50;

  const posX = (canvasW * xPercent) / 100;
  const posY = (canvasH * yPercent) / 100;

  ctx.translate(posX, posY);
  ctx.scale(scale, scale);

  // Font setup
  const fontPx = Math.round((textTrack.fontSize || 36) * (canvasW / 800));
  ctx.font = `800 ${fontPx}px "Plus Jakarta Sans", sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  // Shadow
  if (textTrack.shadowColor) {
    ctx.shadowColor = textTrack.shadowColor;
    ctx.shadowBlur = 10;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 4;
  }

  // Text Stroke
  if (textTrack.strokeColor) {
    ctx.strokeStyle = textTrack.strokeColor;
    ctx.lineWidth = Math.max(3, fontPx * 0.08);
    ctx.strokeText(textTrack.text, 0, 0);
  }

  // Fill text
  ctx.fillStyle = textTrack.color || "#ffffff";
  ctx.fillText(textTrack.text, 0, 0);

  ctx.restore();
}

// Client-Side Video Export via Canvas Capture + MediaRecorder
export async function exportVideoClientSide(
  canvas: HTMLCanvasElement,
  project: Project,
  onProgress: (percent: number) => void
): Promise<Blob> {
  await preloadProjectImages(project);

  const totalDuration = project.slides.reduce((acc, s) => acc + (s.duration || 4), 0);
  const fps = project.fps || 30;
  const totalFrames = Math.ceil(totalDuration * fps);
  const frameDurationMs = 1000 / fps;

  const stream = canvas.captureStream(fps);
  const mimeType = MediaRecorder.isTypeSupported("video/mp4;codecs=avc1")
    ? "video/mp4;codecs=avc1"
    : MediaRecorder.isTypeSupported("video/mp4")
    ? "video/mp4"
    : "video/webm";

  const mediaRecorder = new MediaRecorder(stream, { mimeType });
  const chunks: Blob[] = [];

  mediaRecorder.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };

  const ctx = canvas.getContext("2d")!;
  const dims = getCanvasDimensions(project.aspectRatio);

  return new Promise((resolve, reject) => {
    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: mimeType });
      resolve(blob);
    };

    mediaRecorder.onerror = (e) => reject(e);

    mediaRecorder.start();

    let currentFrame = 0;

    const renderStep = () => {
      if (currentFrame > totalFrames) {
        mediaRecorder.stop();
        return;
      }

      const currentTime = (currentFrame / totalFrames) * totalDuration;
      renderCanvasFrame(ctx, dims.width, dims.height, project, currentTime);

      const percent = Math.min(100, Math.round((currentFrame / totalFrames) * 100));
      onProgress(percent);

      currentFrame++;
      setTimeout(renderStep, frameDurationMs);
    };

    renderStep();
  });
}
