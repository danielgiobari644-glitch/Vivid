import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
  sendPasswordResetEmail
} from "firebase/auth";

export { onAuthStateChanged };
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  deleteDoc, 
  query, 
  where,
  getDocFromServer
} from "firebase/firestore";
import { UserProfile, Project, SavedVideo } from "../types";
import appletConfig from "./firebase-applet-config.json";

let firebaseConfig: any = appletConfig || {
  apiKey: "AIzaSyDemoPlaceholderKeyForStudioApp123",
  authDomain: "vivid-studio-demo.firebaseapp.com",
  projectId: "vivid-studio-demo",
  storageBucket: "vivid-studio-demo.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef123456"
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);

// Test server connection as per Firebase skill mandate
export async function testFirebaseConnection() {
  try {
    await getDocFromServer(doc(db, "test", "connection"));
    return true;
  } catch (error: any) {
    if (error?.message?.includes("client is offline")) {
      console.warn("Firebase client offline, falling back to local mode.");
    }
    return false;
  }
}

// Authentication Helpers
export async function loginWithGoogle(): Promise<UserProfile> {
  const provider = new GoogleAuthProvider();
  const result = await signInWithPopup(auth, provider);
  return {
    uid: result.user.uid,
    email: result.user.email,
    displayName: result.user.displayName,
    photoURL: result.user.photoURL,
  };
}

export async function loginWithEmail(email: string, pass: string): Promise<UserProfile> {
  const result = await signInWithEmailAndPassword(auth, email, pass);
  return {
    uid: result.user.uid,
    email: result.user.email,
    displayName: result.user.displayName,
    photoURL: result.user.photoURL,
  };
}

export async function signUpWithEmail(email: string, pass: string): Promise<UserProfile> {
  const result = await createUserWithEmailAndPassword(auth, email, pass);
  return {
    uid: result.user.uid,
    email: result.user.email,
    displayName: result.user.displayName,
    photoURL: result.user.photoURL,
  };
}

export async function resetPassword(email: string) {
  await sendPasswordResetEmail(auth, email);
}

export async function logoutUser() {
  await firebaseSignOut(auth);
}

// Project Persistence Helpers (Firestore + LocalStorage fallback)
const LOCAL_STORAGE_PROJECTS = "vivid_studio_projects";
const LOCAL_STORAGE_VIDEOS = "vivid_studio_videos";

export async function saveProjectToStorage(project: Project): Promise<void> {
  // Save locally
  const localStr = localStorage.getItem(LOCAL_STORAGE_PROJECTS);
  const localProjects: Project[] = localStr ? JSON.parse(localStr) : [];
  const existingIdx = localProjects.findIndex((p) => p.id === project.id);
  if (existingIdx >= 0) {
    localProjects[existingIdx] = project;
  } else {
    localProjects.unshift(project);
  }
  localStorage.setItem(LOCAL_STORAGE_PROJECTS, JSON.stringify(localProjects));

  // Save to Firestore if user logged in
  if (auth.currentUser) {
    try {
      await setDoc(doc(db, "projects", project.id), {
        ...project,
        userId: auth.currentUser.uid,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      console.warn("Firestore project save error:", err);
    }
  }
}

export async function getProjectsFromStorage(): Promise<Project[]> {
  const localStr = localStorage.getItem(LOCAL_STORAGE_PROJECTS);
  const localProjects: Project[] = localStr ? JSON.parse(localStr) : [];

  if (auth.currentUser) {
    try {
      const q = query(collection(db, "projects"), where("userId", "==", auth.currentUser.uid));
      const querySnap = await getDocs(q);
      const cloudProjects: Project[] = [];
      querySnap.forEach((docSnap) => {
        cloudProjects.push(docSnap.data() as Project);
      });
      if (cloudProjects.length > 0) {
        return cloudProjects;
      }
    } catch (err) {
      console.warn("Firestore fetch error, returning local projects:", err);
    }
  }

  return localProjects;
}

export async function deleteProjectFromStorage(projectId: string): Promise<void> {
  const localStr = localStorage.getItem(LOCAL_STORAGE_PROJECTS);
  if (localStr) {
    const localProjects: Project[] = JSON.parse(localStr);
    const filtered = localProjects.filter((p) => p.id !== projectId);
    localStorage.setItem(LOCAL_STORAGE_PROJECTS, JSON.stringify(filtered));
  }

  if (auth.currentUser) {
    try {
      await deleteDoc(doc(db, "projects", projectId));
    } catch (err) {
      console.warn("Firestore delete error:", err);
    }
  }
}

export async function saveExportedVideo(video: SavedVideo): Promise<void> {
  const localStr = localStorage.getItem(LOCAL_STORAGE_VIDEOS);
  const localVideos: SavedVideo[] = localStr ? JSON.parse(localStr) : [];
  localVideos.unshift(video);
  localStorage.setItem(LOCAL_STORAGE_VIDEOS, JSON.stringify(localVideos));

  if (auth.currentUser) {
    try {
      await setDoc(doc(db, "saved_videos", video.id), {
        ...video,
        userId: auth.currentUser.uid,
      });
    } catch (err) {
      console.warn("Firestore video save error:", err);
    }
  }
}

export async function getSavedVideosFromStorage(): Promise<SavedVideo[]> {
  const localStr = localStorage.getItem(LOCAL_STORAGE_VIDEOS);
  const localVideos: SavedVideo[] = localStr ? JSON.parse(localStr) : [];

  if (auth.currentUser) {
    try {
      const q = query(collection(db, "saved_videos"), where("userId", "==", auth.currentUser.uid));
      const querySnap = await getDocs(q);
      const cloudVideos: SavedVideo[] = [];
      querySnap.forEach((docSnap) => {
        cloudVideos.push(docSnap.data() as SavedVideo);
      });
      if (cloudVideos.length > 0) {
        return cloudVideos;
      }
    } catch (err) {
      console.warn("Firestore saved videos error:", err);
    }
  }

  return localVideos;
}
