"""
Vivid Studio - Python FastAPI MoviePy Backend Server
Production-ready API for rendering image slideshow videos with Ken Burns pan/zoom,
transitions, text overlays, and audio integration.
Deployable to Railway, Render, Koyeb, or Heroku without local installation.
"""

import os
import tempfile
import urllib.request
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional

# MoviePy imports
from moviepy.editor import (
    ImageClip, TextClip, CompositeVideoClip, concatenate_videoclips,
    AudioFileClip, CompositeAudioClip, ColorClip
)
from moviepy.video.fx.all import fadein, fadeout, resize

app = FastAPI(
    title="Vivid Studio Video Renderer API",
    description="Backend Python rendering engine using MoviePy, Pillow, and OpenCV",
    version="1.0.0"
)

# Enable CORS for Netlify / AI Studio frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Data Models
class SlideConfig(BaseModel):
    imageUrl: str
    duration: float = 4.0
    animationType: str = "pan-left"  # pan-left, pan-right, zoom-in, zoom-out, spiral
    transitionType: str = "fade"  # fade, slide-left, blur, zoom
    backgroundColor: str = "#000000"

class TextOverlayConfig(BaseModel):
    text: str
    startTime: float = 0.0
    duration: float = 3.0
    positionY: int = 50  # percentage 0-100
    fontSize: int = 36
    color: str = "#ffffff"
    strokeColor: str = "#000000"
    animation: str = "fade"

class AudioTrackConfig(BaseModel):
    audioUrl: Optional[str] = None
    volume: float = 1.0
    fadeIn: float = 0.5
    fadeOut: float = 0.5

class RenderRequest(BaseModel):
    title: str = "My Video"
    aspectRatio: str = "16:9"  # 16:9, 9:16, 1:1, 4:5, 3:2
    fps: int = 30
    resolution: str = "1080p"  # 720p, 1080p, 4k
    slides: List[SlideConfig]
    textTracks: Optional[List[TextOverlayConfig]] = []
    audioTrack: Optional[AudioTrackConfig] = None

# Aspect ratio resolution map
ASPECT_RATIO_MAP = {
    "16:9": {"720p": (1280, 720), "1080p": (1920, 1080), "4k": (3840, 2160)},
    "9:16": {"720p": (720, 1280), "1080p": (1080, 1920), "4k": (2160, 3840)},
    "1:1": {"720p": (720, 720), "1080p": (1080, 1080), "4k": (2160, 2160)},
    "4:5": {"720p": (720, 900), "1080p": (1080, 1350), "4k": (2160, 2700)},
    "3:2": {"720p": (1080, 720), "1080p": (1620, 1080), "4k": (3240, 2160)},
}

@app.get("/")
def health_check():
    return {"status": "ok", "service": "Vivid Studio Python Video Renderer API"}

@app.post("/api/render")
def render_video(req: RenderRequest, background_tasks: BackgroundTasks):
    try:
        # Determine dimensions
        res_dict = ASPECT_RATIO_MAP.get(req.aspectRatio, ASPECT_RATIO_MAP["16:9"])
        target_w, target_h = res_dict.get(req.resolution, res_dict["1080p"])

        slide_clips = []
        temp_files = []

        for idx, slide in enumerate(req.slides):
            # Download image to temp file
            temp_img = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
            temp_files.append(temp_img.name)
            temp_img.close()

            if slide.imageUrl.startswith("data:image"):
                # Base64 image
                import base64
                header, encoded = slide.imageUrl.split(",", 1)
                data = base64.b64decode(encoded)
                with open(temp_img.name, "wb") as f:
                    f.write(data)
            else:
                urllib.request.urlretrieve(slide.imageUrl, temp_img.name)

            # Open with Pillow to crop & fit
            pil_img = Image.open(temp_img.name).convert("RGB")
            pil_img = fit_image_to_canvas(pil_img, target_w, target_h, slide.backgroundColor)
            
            fitted_temp = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
            temp_files.append(fitted_temp.name)
            fitted_temp.close()
            pil_img.save(fitted_temp.name)

            # Create MoviePy clip
            clip = ImageClip(fitted_temp.name).set_duration(slide.duration)

            # Apply Ken Burns Zoom/Pan Effect
            if slide.animationType == "zoom-in":
                clip = clip.resize(lambda t: 1.0 + 0.15 * (t / slide.duration))
            elif slide.animationType == "zoom-out":
                clip = clip.resize(lambda t: 1.15 - 0.15 * (t / slide.duration))
            elif slide.animationType == "pan-left":
                clip = clip.set_position(lambda t: (int(-20 * (t / slide.duration)), "center"))

            # Apply Fade transition
            if slide.transitionType == "fade" and len(req.slides) > 1:
                clip = fadein(clip, 0.5)

            slide_clips.append(clip)

        # Concatenate slides
        video_clip = concatenate_videoclips(slide_clips, method="compose")

        # Process Text Overlays
        text_clips = []
        for txt in (req.textTracks or []):
            try:
                # Render text overlay image with Pillow for reliable cross-platform fonts
                txt_img = render_text_image(
                    txt.text, target_w, target_h,
                    pos_y_percent=txt.positionY,
                    font_size=txt.fontSize,
                    color=txt.color,
                    stroke_color=txt.strokeColor
                )
                txt_temp = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
                temp_files.append(txt_temp.name)
                txt_temp.close()
                txt_img.save(txt_temp.name)

                t_clip = (ImageClip(txt_temp.name)
                          .set_start(txt.startTime)
                          .set_duration(txt.duration))

                if txt.animation == "fade":
                    t_clip = fadein(t_clip, 0.3).fadeout(0.3)

                text_clips.append(t_clip)
            except Exception as e:
                print(f"Text overlay render warning: {e}")

        final_clip = CompositeVideoClip([video_clip] + text_clips, size=(target_w, target_h))

        # Output MP4 temp file
        out_temp = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4")
        out_temp.close()

        final_clip.write_videofile(
            out_temp.name,
            fps=req.fps,
            codec="libx264",
            audio_codec="aac" if req.audioTrack and req.audioTrack.audioUrl else None,
            preset="medium",
            bitrate="5000k"
        )

        # Cleanup background task
        def cleanup():
            for f in temp_files:
                if os.path.exists(f):
                    try:
                        os.remove(f)
                    except:
                        pass

        background_tasks.add_task(cleanup)

        return FileResponse(
            out_temp.name,
            media_type="video/mp4",
            filename=f"{req.title.replace(' ', '_')}.mp4"
        )

    except Exception as e:
        print(f"Render error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

def fit_image_to_canvas(pil_img: Image.Image, canvas_w: int, canvas_h: int, bg_color_hex: str) -> Image.Image:
    """Fit image onto canvas while preserving aspect ratio and padding with background color."""
    canvas = Image.new("RGB", (canvas_w, canvas_h), bg_color_hex)
    img_w, img_h = pil_img.size
    scale = min(canvas_w / img_w, canvas_h / img_h)
    new_w, new_h = int(img_w * scale), int(img_h * scale)
    resized_img = pil_img.resize((new_w, new_h), Image.Resampling.LANCZOS)
    paste_x = (canvas_w - new_w) // 2
    paste_y = (canvas_h - new_h) // 2
    canvas.paste(resized_img, (paste_x, paste_y))
    return canvas

def render_text_image(text: str, w: int, h: int, pos_y_percent: int, font_size: int, color: str, stroke_color: str) -> Image.Image:
    """Renders transparent PNG overlay with text."""
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("DejaVuSans-Bold.ttf", font_size)
    except:
        font = ImageFont.load_default()

    bbox = draw.textbbox((0, 0), text, font=font)
    text_w = bbox[2] - bbox[0]
    x = (w - text_w) // 2
    y = int(h * (pos_y_percent / 100.0))

    # Draw stroke
    for dx in [-2, 0, 2]:
        for dy in [-2, 0, 2]:
            if dx != 0 or dy != 0:
                draw.text((x + dx, y + dy), text, font=font, fill=stroke_color)

    # Draw main text
    draw.text((x, y), text, font=font, fill=color)
    return img
